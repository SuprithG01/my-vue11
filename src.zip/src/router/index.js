// router/index.js
import Vue from 'vue';
import VueRouter from 'vue-router';
import UserDetailsTab from '@/components/User-Details.vue';
import AccountCreationTab from '@/components/AccountCreation.vue';

Vue.use(VueRouter);

const routes = [
  {
    path: '/',
    redirect: '/User-Details', // Redirect to user details tab by default
  },
  {
    path: '/User-Details',
    component: UserDetailsTab,
    redirect:'/User-Details',
  },
  {
    path: '/AccountCreation',
    component: AccountCreationTab,
    redirect:'/AccountCreation',
  },
];

const router = new VueRouter({
  mode: 'history',
  base: process.env.BASE_URL,
  routes,
});

export default router;