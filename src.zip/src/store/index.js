// store/index.js
import Vue from 'vue';
import Vuex from 'vuex';
import { fetchUsers } from '@/api/userApi.js';

Vue.use(Vuex);

export default new Vuex.Store({
  state: {
    users: [
      { id: 1, username: 'Alice', email: 'alice@example.com', phone: '123-456-7890', creationDate: '2023-11-01' },
      { id: 2, username: 'Bob', email: 'bob@example.com', phone: '987-654-3210', creationDate: '2023-10-15' },
      // Add more mock user data as needed
    ]
  },
  mutations: {
    setUsers(state, users) {
      state.users = users;
    },
  },
  actions: {
    async fetchUsers({ commit }) {
      try {
        const users = await fetchUsers(); // Use the API function
        commit('setUsers', users); // Commit mutation to update state
      } catch (error) {
        console.error('Error fetching users:', error);
      }
    },
  },
  getters: {
    getUsers: (state) => state.users,
  },
});
