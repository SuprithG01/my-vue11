<template>
  <div class="modal">
    <div class="modal-content">
      <span class="close" @click="$emit('closeModal')">&times;</span>
      <h2>User Report for {{ selectedUser.username }}</h2>
      <!-- Report details or actions -->
    </div>
  </div>
</template>

<script>
export default {
  props: {
    selectedUser: Object,
  },
};
</script>

<style>
/* Modal styles */
.modal {
  /* Styles for modal background overlay */
}

.modal-content {
  /* Styles for modal content */
}

.close {
  /* Styles for close button */
}
</style>
