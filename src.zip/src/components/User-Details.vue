<template>
  <div>
    <!-- Search Bar -->
    <input type="text" placeholder="Search..." />

    <!-- User Details Table -->
    <table class="min-w-full">
      <!-- Table headers -->
      <thead>
        <tr>
          <th>Username</th>
          <th>Email</th>
          <th>Phone</th>
          <th>ID</th>
          <th>Creation Date</th>
          <th>Action</th>
        </tr>
      </thead>
      <tbody>
        <!-- Display users -->
        <tr v-for="(user, index) in users" :key="index">
          <td>{{ user.username }}</td>
          <td>{{ user.email }}</td>
          <td>{{ user.phone }}</td>
          <td>{{ user.id }}</td>
          <td>{{ user.creationDate }}</td>
          <td>
            <button @click="openReportModal(user)">Generate Report</button>
          </td>
        </tr>
      </tbody>
    </table>

    <!-- User Report Modal -->
    <UserReportModal v-if="showReportModal" :selectedUser="selectedUser" @closeModal="closeReportModal" />
  </div>
</template>

<script>
import UserReportModal from '@/components/UserReportModal.vue';

export default {
  components: {
    UserReportModal,
  },
  data() {
    return {
      users: [], // Placeholder data
      showReportModal: false,
      selectedUser: null,
    };
  },
  methods: {
    // Fetch users from API
    // Implement search functionality
    openReportModal(user) {
      this.selectedUser = user;
      this.showReportModal = true;
    },
    closeReportModal() {
      this.showReportModal = false;
      this.selectedUser = null;
    },
  },
  mounted() {
    // Fetch users from API upon component mount
    // For demo purposes, use placeholder data
    this.users = [
      { username: 'JohnDoe', email: 'john@example.com', phone: '123-456-7890', id: 1, creationDate: '2023-11-15' },
      // Add more dummy data...
    ];
  },
  created() {
  // Fetching user data from your API
  fetch('https://your-api.com/users') // Replace with your API endpoint
    .then(response => response.json())
    .then(data => {
      this.users = data; // Update the users data with fetched data
    })
    .catch(error => {
      console.error('Error fetching user details:', error);
    });
}

};
</script>
