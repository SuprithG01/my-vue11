<template>
  <div>
    <h2>Create Account</h2>
    <!-- Account Creation Form -->
    <form @submit.prevent="createAccount">
      <div>
        <label for="username">Username:</label>
        <input type="text" id="username" v-model="username" />
      </div>
      <div>
        <label for="password">Password:</label>
        <input type="password" id="password" v-model="password" />
      </div>
      <button type="submit">Create</button>
    </form>
  </div>
</template>

<script>
export default {
  data() {
    return {
      username: '',
      password: '',
    };
  },
  methods: {
    createAccount() {
      // Dummy request handling
      console.log('Creating account with username:', this.username, 'and password:', this.password);
      // Perform API request here to create account
      // Reset form fields after submission
      this.username = '';
      this.password = '';
    },
  },
};
</script>
