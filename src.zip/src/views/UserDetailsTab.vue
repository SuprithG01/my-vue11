<template>
  <div>
    <!-- Search Bar -->
    <input type="text" placeholder="Search..." v-model="searchQuery" />

    <!-- User Details Table -->
    <table class="min-w-full">
      <!-- Table headers -->
      <thead>
        <tr>
          <th>Username</th>
          <th>Email</th>
          <th>Phone</th>
          <th>ID</th>
          <th>Creation Date</th>
          <th>Action</th>
        </tr>
      </thead>
      <tbody>
        <!-- Display users based on search or all users if search is empty -->
        <tr v-for="(user, index) in filteredUsers" :key="index">
          <td>{{ user.username }}</td>
          <td>{{ user.email }}</td>
          <td>{{ user.phone }}</td>
          <td>{{ user.id }}</td>
          <td>{{ user.creationDate }}</td>
          <td>
            <button @click="openReportModal(user)">Generate Report</button>
          </td>
        </tr>
      </tbody>
    </table>

    <!-- User Report Modal -->
    <UserReportModal v-if="showReportModal" :selectedUser="selectedUser" @closeModal="closeReportModal" />
  </div>
</template>

<script>
import UserReportModal from '@/components/UserReportModal.vue';
import { fetchUsers } from '@/api/userApi.js'; // Import the API function to fetch users

export default {
  components: {
    UserReportModal,
  },
  data() {
    return {
      users: [], // Placeholder data
      searchQuery: '',
      showReportModal: false,
      selectedUser: null,
    };
  },
  computed: {
    filteredUsers() {
      if (!this.searchQuery) {
        return this.users; // Display all users if search query is empty
      } else {
        // Filter users based on search query (you may adjust the filtering logic as needed)
        return this.users.filter(user => 
          user.username.toLowerCase().includes(this.searchQuery.toLowerCase())
          || user.email.toLowerCase().includes(this.searchQuery.toLowerCase())
          // Add other fields for searching if required
        );
      }
    },
  },
  methods: {
    async fetchUsersData() {
      try {
        // Fetch users from the API
        this.users = await fetchUsers(); // Assuming fetchUsers returns an array of users
      } catch (error) {
        console.error('Error fetching users:', error);
        // Handle error fetching users
      }
    },
    openReportModal(user) {
      this.selectedUser = user;
      this.showReportModal = true;
    },
    closeReportModal() {
      this.showReportModal = false;
      this.selectedUser = null;
    },
  },
  mounted() {
    this.fetchUsersData(); // Fetch users from the API upon component mount
  },
};
</script>
