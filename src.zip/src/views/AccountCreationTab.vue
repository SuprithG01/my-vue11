<template>
  <div>
    <h2>Create Account</h2>
    <!-- Account Creation Form -->
    <form @submit.prevent="createAccount">
      <div>
        <label for="username">Username:</label>
        <input type="text" id="username" v-model="username" />
      </div>
      <div>
        <label for="password">Password:</label>
        <input type="password" id="password" v-model="password" />
      </div>
      <button type="submit">Create</button>
    </form>
  </div>
</template>

<script>
import { createUser } from '@/api/userApi.js'; // Import the API function to create a user

export default {
  data() {
    return {
      username: '',
      password: '',
    };
  },
  methods: {
    async createAccount() {
      try {
        // Dummy request handling
        const newUser = {
          username: this.username,
          password: this.password,
          // Other user details if required
        };

        // Call API function to create a user
        await createUser(newUser);

        // Reset form fields after successful creation
        this.username = '';
        this.password = '';

        alert('User created successfully!');
      } catch (error) {
        console.error('Error creating user:', error);
        alert('Failed to create user!');
      }
    },
  },
};
</script>
