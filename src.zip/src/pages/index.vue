<template>
  <div class="dashboard">
    <nav>
      <router-link to="/User-Details">User Details</router-link>
      <router-link to="/AccountCreation">Account Creation</router-link>
    </nav>
    <div class="main-content">
      <router-view></router-view>
    </div>
  </div>
</template>

<script>
export default {
  // Component options
}
</script>

<style>
/* Example styles for the dashboard */
.dashboard {
  display: flex;
  flex-direction: column;
  height: 100vh;
  font-family: Arial, sans-serif;
}

nav {
  background-color: #333;
  padding: 10px;
}

nav a {
  margin-right: 10px;
  color: white;
  text-decoration: none;
}

nav a:hover {
  text-decoration: underline;
}

.main-content {
  flex: 1;
  padding: 20px;
}
</style>
