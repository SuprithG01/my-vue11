<template>
  <div id="app">
    <!-- Header -->
    <header>
      <h1>User Management Dashboard</h1>
      <!-- Navigation Links -->
      <nav>
        <router-link to ="/User-Details">User Details</router-link>
        <router-link to ="/AccountCreation">Account Creation </router-link>
      </nav>
    </header>

    <!-- Main Content Area -->
    <main>
      <router-view></router-view>
    </main>

    <!-- Footer -->
    <footer>
      <p>&copy; 2023 MY APP</p>
    </footer>
  </div>
</template>

<script>
export default {
  name: 'App',
  // Component logic can be added if needed


};
</script>

<style>
/* Example styles for the header, footer, and navigation links */
header {
  background-color: #333;
  color: white;
  padding: 20px;
  text-align: center;
}

nav {
  margin-top: 20px;
}

nav router-link {
  margin-right: 20px;
  color: white;
  text-decoration: none;
  cursor:pointer
}

nav router-link:hover {
  text-decoration: underline;
}

main {
  padding: 180px;
  background:url(download.jpeg);
}

footer {
  background-color: #333;
  color: white;
  padding: 10px;
  text-align: center;
}
</style>

